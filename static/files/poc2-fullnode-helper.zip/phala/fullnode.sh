#! /bin/bash
if [ -f "/etc/systemd/system/poc2_fullnode.service" ];then
    rm /etc/systemd/system/poc2_fullnode.service
fi
if [ -f "./script/full_node.sh" ];then
    rm ./script/full_node.sh
fi
cp ./tmp/full_node.sh ./script
sed -i "s/phala-fullnode-1/$1/g" ./script/full_node.sh
cp ./poc2_fullnode_1.service /etc/systemd/system
chmod +x /etc/systemd/system/poc2_fullnode_1.service
chmod +x ./script/full_node.sh
chmod +x ./phala-node
systemctl enable poc2_fullnode_1.service
systemctl stop poc2_fullnode_1.service
systemctl start poc2_fullnode_1.service
