#!/bin/bash

NODE_NAME="phala-validator-1"
P2P_PORT="31333"
WORK_PATH=$(dirname $(dirname $(readlink -f "$0")))
BASE_PATH_BASE="$HOME/data/$NODE_NAME"
CHAIN_NAME="phala"
WASM_EXECUTION_MODE="Compiled" # Interpreted
RPC_PORT=9133
RESERVED_NODES="/ip4/10.40.96.3/tcp/30333/p2p/12D3KooWQsdYh5xUsLSTexqXxxb87nSAZsLd8KiUnxemN4z1hAVe"

$WORK_PATH/phala-node \
  --chain $CHAIN_NAME \
  --base-path $BASE_PATH_BASE \
  --database paritydb \
  --wasm-execution $WASM_EXECUTION_MODE  \
  --name $NODE_NAME \
  --validator \
  --port $P2P_PORT \
  --rpc-port $RPC_PORT \
  --reserved-nodes $RESERVED_NODES \
  "$@"
